<!DOCTYPE html>
<html>
<head>
    <title>Creating evenement</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar navbar-inverse">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(URL::to('evenement')); ?>">Evenement Alert</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="<?php echo e(URL::to('evenement')); ?>">View All evenement</a></li>
            <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Create a evenement</a>
        </ul>
    </nav>

    <h1>Create a evenement</h1>
    <h1>Create a evenement</h1>

    <!-- if there are creation errors, they will show here -->
    <?php echo e(Html::ul($errors->all())); ?>


    <?php echo e(Form::open(array('url' => 'evenement'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('naam', 'Naam')); ?>

        <?php echo e(Form::text('naam', Input::old('Naam'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('beginDatum', 'BeginDatum')); ?>

        <?php echo e(Form::text('beginDatum', Input::old('beginDatum'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('eindDatum', 'EindDatum')); ?>

        <?php echo e(Form::text('eindDatum', Input::old('eindDatum'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('klantId', 'KlantId')); ?>

        <?php echo e(Form::text('KlantId', Input::old('klantId'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('prijs', 'Prijs')); ?>

        <?php echo e(Form::text('prijs', Input::old('prijs'), array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Create the evenement!', array('class' => 'btn btn-primary'))); ?>


    <?php echo e(Form::close()); ?>


</div>
</body>
</html>