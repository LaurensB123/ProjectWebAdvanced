<!DOCTYPE html>
<html>
<head>
    <title>Edit evenement</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('evenement')); ?>">Evenementen</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('evenement')); ?>">View All Evenement</a></li>
        <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Create a Evenement</a>
    </ul>
</nav>

<h1>Edit <?php echo e($evenement->name); ?></h1>

<!-- if there are creation errors, they will show here -->
<?php echo e(Html::ul($errors->all())); ?>


<?php echo e(Form::model($evenement, array('route' => array('evenement.update', $evenement->id), 'method' => 'PUT'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('naam', 'Naam')); ?>

        <?php echo e(Form::text('naam', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('beginDatum', 'BeginDatum')); ?>

        <?php echo e(Form::text('beginDatum', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('eindDatum', 'EindDatum')); ?>

        <?php echo e(Form::text('eindDatum', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('klantId', 'KlantId')); ?>

        <?php echo e(Form::text('KlantId', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('prijs', 'Prijs')); ?>

        <?php echo e(Form::text('prijs', null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Edit the Evenement!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


</div>
</body>
</html>