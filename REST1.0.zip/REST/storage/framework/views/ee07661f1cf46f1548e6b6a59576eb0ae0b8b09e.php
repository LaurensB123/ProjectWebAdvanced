<!DOCTYPE html>
<html>
<head>
    <title>Show evenement</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

    <nav class="navbar navbar-inverse">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(URL::to('evenement')); ?>">Evenementen beheer</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="<?php echo e(URL::to('evenement')); ?>">View All evenementen</a></li>
            <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Create a evenementen</a>
        </ul>
    </nav>

    <h1>Showing <?php echo e($evenement->name); ?></h1>

    <div class="jumbotron text-center">
        <h2><?php echo e($evenement->name); ?></h2>
        <p>
            <strong>beginDatum:</strong> <?php echo e($evenement->beginDatum); ?><br>
            <strong>eindDatum:</strong> <?php echo e($evenement->eindDatum); ?><br>
            <strong>klantId:</strong> <?php echo e($evenement->klantId); ?><br>
            <strong>prijs:</strong> <?php echo e($evenement->prijs); ?>

        </p>
    </div>

</div>
</body>
</html>