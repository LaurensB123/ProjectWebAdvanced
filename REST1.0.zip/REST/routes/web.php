<?php

Route::resource("evenement", "EvenementController", []);

