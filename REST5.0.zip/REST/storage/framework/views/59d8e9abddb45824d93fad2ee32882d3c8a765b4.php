<!DOCTYPE html>
<html>
<head>
    <title>Creating evenement</title>
    <link href="<?php echo asset('css/opmaak.css'); ?>" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="<?php echo e(URL::to('evenement')); ?>">Evenementen</a>

        <ul>
            <li><a href="<?php echo e(URL::to('evenement')); ?>">Toon alle evenementen</a></li>
            <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Creëer een evenement</h1>

    <!-- if there are creation errors, they will show here -->
    <?php echo e(Html::ul($errors->all())); ?>


    <?php echo e(Form::open(array('url' => 'evenement'))); ?>


    <table>

        <tr>

            <td><?php echo e(Form::label('naam', 'Naam')); ?></td>
            <td><?php echo e(Form::text('naam', Input::old('Naam'), array('class' => 'form-control'))); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::label('beginDatum', 'Begin datum')); ?></td>
            <td><?php echo e(Form::text('beginDatum', Input::old('beginDatum'), array('class' => 'form-control'))); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::label('eindDatum', 'Eind datum')); ?></td>
            <td><?php echo e(Form::text('eindDatum', Input::old('eindDatum'), array('class' => 'form-control'))); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::label('klantId', 'Klant id')); ?></td>
            <td><?php echo e(Form::number('klantId', Input::old('klantId'), array('class' => 'form-control'))); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::label('prijs', 'Prijs')); ?></td>
            <td><?php echo e(Form::text('prijs', Input::old('prijs'), array('class' => 'form-control'))); ?></td>
        </tr>
    </table>
    <?php echo e(Form::submit('Creëer evenement', array('class' => 'btn btn-primary'))); ?>


    <?php echo e(Form::close()); ?>


</div>
</body>
</html>