<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evenement Beheer</title>
    <link href="{!! asset('css/opmaak.css') !!}" media="all" rel="stylesheet" type="text/css"/>
</head>

<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="{{ URL::to('evenement') }}">Evenementen</a>

        <ul>
            <li><a href="{{ URL::to('evenement') }}">Toon alle evenementen</a></li>
            <li><a href="{{ URL::to('evenement/create') }}">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Evenementen overzicht</h1>

    <!-- will be used to show any messages -->
    @if (Session::has('message'))
        <div>{{ Session::get('message') }}</div>
    @endif

    <table>
        <thead>
        <tr class="titelrij">
            <td>ID</td>
            <td>Naam</td>
            <td>Begin datum</td>
            <td>Eind datum</td>
            <td>Klant nummer</td>
            <td>Prijs</td>
            <td></td>

        </tr>
        </thead>

        <tbody>
        @foreach($evenement as $key => $value)
            <tr>
                <td>{{ $value->id }}</td>
                <td>{{ $value->naam }}</td>
                <td>{{ $value->beginDatum }}</td>
                <td>{{ $value->eindDatum }}</td>
                <td>{{ $value->klantId }}</td>
                <td>{{ $value->prijs }}</td>
                <td>
                    {{ Form::open(array("url" => "evenement/" . $value->id, "class" => "pull-right")) }}
                    {{ Form::hidden("_method", "DELETE") }}
                    {{ Form::submit("Verwijder", array("class" => "btn")) }}
                    {{ Form::close() }}
                    <a class="btn" href="{{ URL::to('evenement/' . $value->id) }}">Toon</a>
                    <a class="btn" href="{{ URL::to('evenement/' . $value->id . '/edit') }}">Bewerk</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>