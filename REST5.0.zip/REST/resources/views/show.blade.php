<!DOCTYPE html>
<html>
<head>
    <title>Evenement Beheer</title>
    <link href="{!! asset('css/opmaak.css') !!}" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="{{ URL::to('evenement') }}">Evenementen</a>

        <ul>
            <li><a href="{{ URL::to('evenement') }}">Toon alle evenementen</a></li>
            <li><a href="{{ URL::to('evenement/create') }}">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Toon evenement {{ $evenement->name }}</h1>

    <h2>{{ $evenement->name }}</h2>
    <table>
        <tr>
            <td><strong>Begin datum:</strong> {{ $evenement->beginDatum }}</td>
        </tr>
        <tr>
            <td><strong>Eind datum:</strong> {{ $evenement->eindDatum }}</td>
        </tr>
        <tr>
            <td><strong>Klant id:</strong> {{ $evenement->klantId }}</td>
        </tr>
        <tr>
            <td><strong>Prijs:</strong> {{ $evenement->prijs }}</td>
        </tr>
    </table>
</div>
</body>
</html>