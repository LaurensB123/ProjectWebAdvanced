/**
 * Created by 11402595 on 22/05/2017.
 */
function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
    return parent.appendChild(el);
}

const ul = document.getElementById('events');
const url = 'http://localhost:8000/evenement';
fetch(url)
    .then((resp) => resp.json())
.then(function(data) {
    let events = data.results;
    return events.map(function(event) {
        let li = createNode('li'),
            img = createNode('img'),
            span = createNode('span');

        span.innerHTML = `${event.id} ${event.naam} ${event.beginDatum} ${event.eindDatum}`;
        append(li, span);
        append(ul, li);
    })
})
    .catch(function(error) {
        console.log(error);
    });