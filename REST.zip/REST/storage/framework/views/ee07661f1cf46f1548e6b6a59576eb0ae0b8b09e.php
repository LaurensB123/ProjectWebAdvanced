<!DOCTYPE html>
<html>
<head>
    <title>Show evenement</title>
    <link href="<?php echo asset('css/opmaak.css'); ?>" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="<?php echo e(URL::to('evenement')); ?>">Evenementen</a>

        <ul>
            <li><a href="<?php echo e(URL::to('evenement')); ?>">Toon alle evenementen</a></li>
            <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Toon evenement <?php echo e($evenement->name); ?></h1>

    <h2><?php echo e($evenement->name); ?></h2>
    <table>
        <tr>
            <td><strong>Begin datum:</strong> <?php echo e($evenement->beginDatum); ?></td>
        </tr>
        <tr>
            <td><strong>Eind datum:</strong> <?php echo e($evenement->eindDatum); ?></td>
        </tr>
        <tr>
            <td><strong>Klant id:</strong> <?php echo e($evenement->klantId); ?></td>
        </tr>
        <tr>
            <td><strong>Prijs:</strong> <?php echo e($evenement->prijs); ?></td>
        </tr>
    </table>
</div>
</body>
</html>