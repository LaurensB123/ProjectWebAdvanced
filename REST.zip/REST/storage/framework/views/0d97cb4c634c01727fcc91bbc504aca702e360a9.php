<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evenement Beheer</title>
    <link href="<?php echo asset('css/opmaak.css'); ?>" media="all" rel="stylesheet" type="text/css"/>
</head>

<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="<?php echo e(URL::to('evenement')); ?>">Evenementen</a>

        <ul>
            <li><a href="<?php echo e(URL::to('evenement')); ?>">Toon alle evenementen</a></li>
            <li><a href="<?php echo e(URL::to('evenement/create')); ?>">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Evenementen overzicht</h1>

    <!-- will be used to show any messages -->
    <?php if(Session::has('message')): ?>
        <div><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>

    <table>
        <thead>
        <tr class="titelrij">
            <td>ID</td>
            <td>Naam</td>
            <td>Begin datum</td>
            <td>Eind datum</td>
            <td>Klant nummer</td>
            <td>Prijs</td>
            <td></td>

        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $evenement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->naam); ?></td>
                <td><?php echo e($value->beginDatum); ?></td>
                <td><?php echo e($value->eindDatum); ?></td>
                <td><?php echo e($value->klantId); ?></td>
                <td><?php echo e($value->prijs); ?></td>
                <td>
                    <?php echo e(Form::open(array("url" => "evenement/" . $value->id, "class" => "pull-right"))); ?>

                    <?php echo e(Form::hidden("_method", "DELETE")); ?>

                    <?php echo e(Form::submit("Verwijder", array("class" => "btn"))); ?>

                    <?php echo e(Form::close()); ?>

                    <a class="btn" href="<?php echo e(URL::to('evenement/' . $value->id)); ?>">Toon</a>
                    <a class="btn" href="<?php echo e(URL::to('evenement/' . $value->id . '/edit')); ?>">Bewerk</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>