<!DOCTYPE html>
<html>
<head>
    <title>Evenement Beheer</title>
    <link href="{!! asset('css/opmaak.css') !!}" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="{{ URL::to('evenement') }}">Evenementen</a>

        <ul>
            <li><a href="{{ URL::to('evenement') }}">Toon alle evenementen</a></li>
            <li><a href="{{ URL::to('evenement/create') }}">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Creëer een evenement</h1>

    <!-- if there are creation errors, they will show here -->
    {{ Html::ul($errors->all()) }}

    {{ Form::open(array('url' => 'evenement')) }}

    <table>

        <tr>

            <td>{{ Form::label('naam', 'Naam') }}</td>
            <td>{{ Form::text('naam', Input::old('Naam'), array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('beginDatum', 'Begin datum') }}</td>
            <td>{{ Form::text('beginDatum', Input::old('beginDatum'), array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('eindDatum', 'Eind datum') }}</td>
            <td>{{ Form::text('eindDatum', Input::old('eindDatum'), array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('klantId', 'Klant id') }}</td>
            <td>{{ Form::number('klantId', Input::old('klantId'), array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('prijs', 'Prijs') }}</td>
            <td>{{ Form::text('prijs', Input::old('prijs'), array('class' => 'form-control')) }}</td>
        </tr>
    </table>
    {{ Form::submit('Creëer evenement', array('class' => 'btn btn-primary')) }}

    {{ Form::close() }}

</div>
</body>
</html>