<!DOCTYPE html>
<html>
<head>
    <title>Evenement Beheer</title>
    <link href="{!! asset('css/opmaak.css') !!}" media="all" rel="stylesheet" type="text/css"/>
</head>
<body>
<div style="overflow-x:auto;">
    <div class="header">
        <a href="{{ URL::to('evenement') }}">Evenementen</a>

        <ul>
            <li><a href="{{ URL::to('evenement') }}">Toon alle evenementen</a></li>
            <li><a href="{{ URL::to('evenement/create') }}">Maak een evenement</a></li>
        </ul>
    </div>

    <h1>Edit {{ $evenement->name }}</h1>

    <!-- if there are creation errors, they will show here -->
    {{ Html::ul($errors->all()) }}

    {{ Form::model($evenement, array('route' => array('evenement.update', $evenement->id), 'method' => 'PUT')) }}

    <table>
        <tr>

            <td> {{ Form::label('naam', 'Naam') }}</td>
            <td>{{ Form::text('naam', null, array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('beginDatum', 'BeginDatum') }}</td>
            <td>{{ Form::text('beginDatum', null, array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td>{{ Form::label('eindDatum', 'EindDatum') }}</td>
            <td> {{ Form::text('eindDatum', null, array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td> {{ Form::label('klantId', 'KlantId') }}</td>
            <td>{{ Form::number('klantId', null, array('class' => 'form-control')) }}</td>
        </tr>
        <tr>
            <td> {{ Form::label('prijs', 'Prijs') }}</td>
            <td> {{ Form::text('prijs', null, array('class' => 'form-control')) }}</td>

        </tr>
    </table>
    {{ Form::submit('Edit', array('class' => 'btn btn-primary')) }}

    {{ Form::close() }}

</div>
</body>
</html>